#!/bin/bash


cd  Part2/Timer


echo " Philo"
#./PhilosophesOurSem.sh

echo " ProdCons"

#./ProdconsOurSem.sh

echo " lececriv.sh"

#./LececrivOurSem.sh

echo "TestAndSet"

cd ../TestAndSet

./testandset.sh

echo "TestAndTestAndSet"

cd ../TestAndTestAndSet

./TestAndTestAndSet.sh


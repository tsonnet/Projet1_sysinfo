#!/bin/bash

make philosophes
make data_philo

make lececriv
make data_lececriv

make prodcons
make data_prodcons

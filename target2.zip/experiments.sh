#!/bin/bash


cd  Part1/Timer


echo " Philo"
./philosophes.sh

echo " ProdCons"

./prodcons.sh

echo " lececriv.sh"

./lececriv.sh